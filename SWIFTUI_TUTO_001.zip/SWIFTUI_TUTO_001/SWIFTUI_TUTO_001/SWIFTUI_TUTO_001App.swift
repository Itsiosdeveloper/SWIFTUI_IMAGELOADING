//
//  SWIFTUI_TUTO_001App.swift
//  SWIFTUI_TUTO_001
//
//  Created by SMH on 25/06/24.
//

import SwiftUI

@main
struct SWIFTUI_TUTO_001App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
