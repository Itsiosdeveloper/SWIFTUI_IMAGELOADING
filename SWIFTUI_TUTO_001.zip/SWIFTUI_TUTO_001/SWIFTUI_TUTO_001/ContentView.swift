//
//  ContentView.swift
//  SWIFTUI_TUTO_002
//
//  Created by SMH on 25/06/24.
//

import SwiftUI

struct ContentView: View {
    @State private var isAnimating = false
    
    
    var body: some View {
        VStack {
            //Beginner Level:
            //USING SYSTEM IMAGE
            Image(systemName: "star")
                .foregroundColor(.red)
                .font(.title)
            
            //USING IMAGES FROM ASSESTS
            Image("images01")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
            
            //Intermediate Level:
            Image(systemName: "star.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .foregroundColor(.yellow)
                .padding()
                .background(Color.blue)
                .clipShape(Circle())
                .shadow(radius: 10)
            
            //Advanced Level:
            Image(systemName: isAnimating ? "star.fill" : "star")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .foregroundColor(isAnimating ? .red : .blue)
                .padding()
                .background(isAnimating ? Color.yellow : Color.green)
                .clipShape(RoundedRectangle(cornerRadius: isAnimating ? 20 : 0))
                .shadow(radius: isAnimating ? 10 : 0)
                .onTapGesture {
                    withAnimation {
                        self.isAnimating.toggle()
                    }
                }
            
            // Load image from URL
            RemoteImage(url: URL(string: "https://picsum.photos/200/300"))
                .scaledToFit()
                .frame(width: 200, height: 200)
            
            
        }
        .padding()
    }
}
struct RemoteImage: View {
    private var url: URL?

    init(url: URL?) {
        self.url = url
    }

    var body: some View {
        Group {
            if let url = url, let imageData = try? Data(contentsOf: url), let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
            } else {
                Image(systemName: "photo") // Default image incase image not load from URL
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
